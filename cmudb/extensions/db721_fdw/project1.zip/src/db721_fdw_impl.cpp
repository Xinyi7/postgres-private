// If you choose to use C++, read this very carefully:
// https://www.postgresql.org/docs/15/xfunc-c.html#EXTEND-CPP

#include "dog.h"
#include "json.hpp"

// clang-format off
extern "C" {
#include "../../../../src/include/postgres.h"
#include "../../../../src/include/fmgr.h"
#include "../../../../src/include/optimizer/clauses.h"
#include "../../../../src/include/foreign/fdwapi.h"
#include "../../../../src/include/foreign/foreign.h"
#include "../../../../src/include/access/reloptions.h"
#include "../../../../src/include/commands/defrem.h"
#include "../../../../src/include/utils/rel.h"
#include "../../../../src/include/optimizer/pathnode.h"
#include "../../../../src/include/optimizer/restrictinfo.h"
#include "../../../../src/include/optimizer/planmain.h"
#include "../../../../src/include/utils/lsyscache.h"
#include "../../../../src/include/optimizer/optimizer.h"
#include "../../../../src/include/utils/builtins.h"
#include "../../../../src/include/executor/execExpr.h"
#include "../../../../src/include/nodes/makefuncs.h"
#include "../../../../src/include/nodes/primnodes.h"

}
// clang-format on
using json = nlohmann::json;
typedef struct Db721_file{
    char * filename;
    FILE * f_oid;
    char * buf;
    json metadata;
    int block_idx;
    int tuple_idx;
    List * column_list;
    int num_block;
    int * column_idx_list;
    int * column_type_list; // type 0: str, 1: int, 2: float
    int remain_tuple;
    int * column_idx_list_map;
    bool return_null;
    int * column_start_idx;
    int max_per_block;
    List * restrict_info_list;
} Db721_file;
static List * getColumns( List *targetColumnList , List *restrictInfoList, RelOptInfo *baserel);

extern "C" void db721_GetForeignRelSize(PlannerInfo *root, RelOptInfo *baserel,
                                      Oid foreigntableid) {

}

extern "C" void db721_GetForeignPaths(PlannerInfo *root, RelOptInfo *baserel,
                                    Oid foreigntableid) {

    Path *path = (Path *)create_foreignscan_path(root, baserel, NULL,              /* default pathtarget */
                                               baserel->rows,     /* rows */
                                               1,                 /* startup cost */
                                               1 + baserel->rows, /* total cost */
                                               NULL,               /* no pathkeys */
                                               NULL,              /* no required outer relids */
                                               NULL,              /* no fdw_outerpath */
                                               NIL);              /* no fdw_private */
    add_path(baserel, path);
}



extern "C" ForeignScan *
db721_GetForeignPlan(PlannerInfo *root, RelOptInfo *baserel, Oid foreigntableid,
                   ForeignPath *best_path, List *tlist, List *scan_clauses,
                   Plan *outer_plan) {
    List *targetColumnList = baserel->reltarget->exprs;
    List *restrictInfoList = baserel->baserestrictinfo;
    List * new_restrict_list = NIL;

    ListCell * restrictInfoCell = NULL;
    foreach(restrictInfoCell, restrictInfoList)
    {
        RestrictInfo *restrictInfo = (RestrictInfo *) lfirst(restrictInfoCell);
        OpExpr * ope_expr = (OpExpr *)restrictInfo->clause;
        if (IsA(linitial(ope_expr->args), Const)){
            CommuteOpExpr(ope_expr);
        }

        new_restrict_list = lappend(new_restrict_list, ope_expr);
    }

    List *columnList = getColumns(targetColumnList , restrictInfoList, baserel);

    auto foreignColumnList = list_make2(columnList, new_restrict_list);

    scan_clauses = extract_actual_clauses(scan_clauses, false);
    return make_foreignscan(tlist,
                            NIL,//scan_clauses,
                            baserel->relid,
                            NIL, /* no expressions we will evaluate */
                            foreignColumnList, /* pass in private data */
                            NIL, /* no custom tlist; our scan tuple looks like tlist */
                            NIL, /* no quals we will recheck */
                            outer_plan);
}
static List * getColumns( List *targetColumnList , List *restrictInfoList, RelOptInfo *baserel){


    List *columnList = NIL;
    List * tmpColumnList = NIL;
    ListCell * restrictInfoCell = NULL;

    foreach(restrictInfoCell, restrictInfoList)
    {
        RestrictInfo *restrictInfo = (RestrictInfo *) lfirst(restrictInfoCell);
        Node *restrictClause = (Node *) restrictInfo->clause;

        // recursively pull up any columns used in the restriction clause
        List * clauseColumnList = pull_var_clause(restrictClause,
                                           PVC_RECURSE_AGGREGATES|
                                           PVC_RECURSE_PLACEHOLDERS);

        tmpColumnList = list_union(tmpColumnList, clauseColumnList);
    }


    for (int columnIndex = 1; columnIndex <= baserel->max_attr; columnIndex++)
    {
        Var *column = NULL;
        ListCell * tmpColumnCell = NULL;
        // look for this column in the needed column list
        foreach(tmpColumnCell, tmpColumnList)
        {
            Var *tmpColumn = (Var *) lfirst(tmpColumnCell);
            if (tmpColumn->varattno == columnIndex)
            {
                column = tmpColumn;
                break;
            }
        }
        tmpColumnCell = NULL;
        if (column == NULL){
            foreach(tmpColumnCell, targetColumnList){
                Var *tmpColumn = (Var *) lfirst(tmpColumnCell);
                if (tmpColumn->varattno == columnIndex)
                {
                    column = tmpColumn;
                    break;
                }
            }
        }

        if (column != NULL)
        {
            columnList = lappend(columnList, column);
        }
    }
    return columnList;

}
extern "C" void db721_BeginForeignScan(ForeignScanState *node, int eflags) {                                
  // TODO(721): Write me!
    int f_id = RelationGetRelid(node->ss.ss_currentRelation);
    auto f_table = GetForeignTable(f_id);
    auto f_server = GetForeignServer(f_table->serverid);

    List *options_list = NULL;
    options_list = list_concat(options_list, f_table->options);
    options_list = list_concat(options_list, f_server->options);
    char *filename = NULL;
    ListCell *cell;
    Db721_file * file_state = (Db721_file *) palloc(sizeof(Db721_file));

    foreach(cell, options_list)
    {
        DefElem *def = (DefElem *) lfirst(cell);
        if (strcmp(def->defname, "filename") == 0) {
            filename = defGetString(def);
        }
    }


    file_state->filename = filename;

    file_state->f_oid = fopen(filename, "r");
    fseek(file_state->f_oid, -4, SEEK_END);

    int size;

    size_t read_size = fread((char *) &size, 4, 1, file_state->f_oid);

    if (read_size ==  0) {
        elog(ERROR, "json metadata size read invalid");
    }
    fseek(file_state->f_oid, -4 - size, SEEK_END);
//    elog(LOG, "db721_BeginForeignScan: %d", size);

    char json_buf[size + 1] = "";
    json_buf[size] = '\0';
    read_size = fread(json_buf,1,  size, file_state->f_oid);
    if (read_size == 0) {
        elog(ERROR, "json metadata read invalid");
    }


    std::string json_str(json_buf);

    file_state->metadata  = json::parse(json_str);
    file_state->return_null = false;

    int max_per_block = int(file_state->metadata["Max Values Per Block"]);
    file_state->max_per_block = max_per_block;
    int tuple_size = 0;
    file_state->tuple_idx = max_per_block;
    file_state->block_idx = 0;
    auto foreign_scan = (ForeignScan *) node->ss.ps.plan;
    List * foreign_column_list = (List *) foreign_scan->fdw_private;
    List * columnList = (List *) linitial(foreign_column_list);
    List * restrictInfoList = (List *)  lsecond(foreign_column_list);
    file_state->restrict_info_list = restrictInfoList;

    ListCell *columnCell = NULL;
    file_state->column_list = columnList;

    file_state->column_idx_list = (int*)palloc(list_length(columnList) * sizeof(int));
    file_state->column_type_list =  (int*)palloc(list_length(columnList) * sizeof(int));
    file_state->num_block = 0;
    file_state->remain_tuple = 0;
    int num_columns = file_state->metadata["Columns"].size();
    file_state->column_idx_list_map = (int*) palloc( num_columns *  sizeof(int));
    file_state->column_start_idx = (int*)palloc(list_length(columnList) * sizeof(int));
    int new_column_idx = 0;
    foreach(columnCell, columnList){
        Var *column = (Var *) lfirst(columnCell);
        AttrNumber column_id = column->varattno;
        auto column_name = get_attname(f_id, column_id, false);
        auto type_str = file_state->metadata["Columns"][column_name]["type"].get<std::string>();


        int start_idx = file_state->metadata["Columns"][column_name]["start_offset"].get<int>();
        file_state->column_start_idx[new_column_idx] = start_idx;

        std::string block_index_str = std::to_string(file_state->block_idx);
        file_state->column_idx_list_map[column_id-1] = new_column_idx;
        if (type_str.compare("str") == 0){
            tuple_size += 32;
            file_state->column_type_list[new_column_idx] = 0;
        }else if (type_str.compare( "int") == 0) {
            tuple_size += 4;
            file_state->column_type_list[new_column_idx] = 1;
        }else if ( type_str.compare("float") == 0){
            tuple_size += 4;
            file_state->column_type_list[new_column_idx] = 2;
        }

        if (file_state->num_block == 0){
            file_state->num_block = file_state->metadata["Columns"][column_name]["num_blocks"].get<int>();
        }
        if (file_state->remain_tuple == 0){
            file_state->remain_tuple = file_state->metadata["Columns"][column_name]["block_stats"][std::to_string(file_state->num_block-1)]["num"].get<int>();
        }
        new_column_idx++;
    }






    file_state->buf = (char *)palloc(tuple_size * max_per_block);
    node->fdw_state = file_state;
}

extern "C" TupleTableSlot *db721_IterateForeignScan(ForeignScanState *node) {

    Db721_file * file_state = (Db721_file *) node->fdw_state;
    int max_per_block = file_state->max_per_block;
    int f_id = RelationGetRelid(node->ss.ss_currentRelation);

    TupleTableSlot * tupleSlot = node->ss.ss_ScanTupleSlot;

    ExecClearTuple(tupleSlot);
    TupleDesc tupleDescriptor = tupleSlot->tts_tupleDescriptor;
    Datum *columnValues = tupleSlot->tts_values;
    bool *columnNulls = tupleSlot->tts_isnull;
    int columnCount = tupleDescriptor->natts;
    memset(columnValues, 0, columnCount * sizeof(Datum));
    memset(columnNulls, true, columnCount * sizeof(bool));
    if (file_state->return_null) {
        return tupleSlot;
    }
    List *target_list = node->ss.ps.plan->targetlist;
    bool tuple_null = false;
    int num_columns = list_length(file_state->column_list);

    List * restrictInfoList = file_state->restrict_info_list;
    while((file_state->block_idx < file_state->num_block)|| ((file_state->block_idx == file_state->num_block) &&
          (file_state->tuple_idx < file_state->remain_tuple))) {

        while (!file_state->return_null && (file_state->block_idx < file_state->num_block) &&
               (file_state->tuple_idx == max_per_block)) {
            file_state->tuple_idx = 0;
            ListCell *columnCell = NULL;


            tuple_null = false;

            ListCell *restrictInfoCell = NULL;
            foreach(restrictInfoCell, restrictInfoList)
            {

                OpExpr *ope_expr  = (OpExpr *) lfirst(restrictInfoCell);


                Const *constant_2 = (Const *) lsecond(ope_expr->args);
                Var *left_var;
                if (IsA(linitial(ope_expr->args), RelabelType)){
                    left_var = (Var *) (((RelabelType *) linitial(ope_expr->args))->arg);
                }else {
                    left_var = (Var *) linitial(ope_expr->args);
                }
                AttrNumber column_id = left_var->varattno;
                auto column_name = get_attname(f_id, column_id, false);
                int i = column_id - 1;
                char *op_name = get_opname(ope_expr->opno);

                if (strcmp(op_name, ">") == 0) {

                    switch (file_state->column_type_list[file_state->column_idx_list_map[i]]) {
                        case 0: {
                            std::string block_max_str = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<std::string>();
                            text * constant_2_value_text =  DatumGetTextP(constant_2->constvalue);
                            int constant_2_size = VARSIZE_ANY_EXHDR(constant_2_value_text);
                            char constant_2_value_str[constant_2_size];
                            strncpy(constant_2_value_str, VARDATA_ANY(constant_2_value_text), constant_2_size);
                            constant_2_value_str[constant_2_size] = '\0';

                            if (strcasecmp(block_max_str.c_str() ,constant_2_value_str) <= 0) {
                                tuple_null = true;
                            }
                            break;
                        }
                        case 1: {
                            int block_max = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<int>();

                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (block_max <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (block_max <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (block_max <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (block_max <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                            break;
                        }
                        case 2: {

                            float block_max = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<float>();

                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (block_max <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (block_max <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (block_max <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (block_max <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }        else if (strcmp(op_name, "=") == 0) {
                    switch (file_state->column_type_list[file_state->column_idx_list_map[i]]) {
                        case 0: {
                            std::string block_min_str = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<std::string>();
                            std::string block_max_str = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<std::string>();
                            text * constant_2_value_text =  DatumGetTextP(constant_2->constvalue);
                            int constant_2_size = VARSIZE_ANY_EXHDR(constant_2_value_text);
                            char constant_2_value_str[constant_2_size];
                            strncpy(constant_2_value_str, VARDATA_ANY(constant_2_value_text), constant_2_size);
                            constant_2_value_str[constant_2_size] = '\0';


                            if (strcasecmp(constant_2_value_str, block_max_str.c_str()) > 0 ||
                                strcasecmp(constant_2_value_str, block_min_str.c_str()) < 0) {
                                tuple_null = true;
                            }
                            break;
                        }
                        case 1: {
                            int block_min = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<int>();
                            int block_max = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<int>();
                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value_int = DatumGetInt32(constant_2->constvalue);
                                    if (constant_2_value_int > block_max || constant_2_value_int < block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value_int = DatumGetInt64(constant_2->constvalue);
                                    if (constant_2_value_int > block_max || constant_2_value_int < block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (constant_2_value > block_max || constant_2_value < block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (constant_2_value > block_max || constant_2_value < block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                            break;
                        }
                        case 2: {
                            float block_min = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<float>();
                            float block_max = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<float>();

                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value_int = DatumGetInt32(constant_2->constvalue);
                                    if (constant_2_value_int > block_max || constant_2_value_int < block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value_int = DatumGetInt32(constant_2->constvalue);
                                    if (constant_2_value_int > block_max || constant_2_value_int < block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (constant_2_value > block_max || constant_2_value < block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (constant_2_value > block_max || constant_2_value < block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                            break;
                        }
                    }
                } else if (strcmp(op_name, "<") == 0) {
                    switch (file_state->column_type_list[file_state->column_idx_list_map[i]]) {
                        case 0: {
                            std::string block_min_str = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<std::string>();

                            text *constant_2_value_text = DatumGetTextP(constant_2->constvalue);
                            int constant_2_size = VARSIZE_ANY_EXHDR(constant_2_value_text);
                            char constant_2_value_str[constant_2_size];
                            strncpy(constant_2_value_str, VARDATA_ANY(constant_2_value_text), constant_2_size);
                            constant_2_value_str[constant_2_size] = '\0';


                            if (strcasecmp(block_min_str.c_str(), constant_2_value_str) >= 0) {
                                tuple_null = true;
                            }
                            break;
                        }
                        case 1: {
                            int block_min = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<int>();


                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (block_min >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (block_min >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (block_min >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (block_min >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }


                            break;
                        }
                        case 2: {
                            float block_min = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<float>();
                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (block_min >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (block_min >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (block_min >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (block_min >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                            break;
                        }
                    }
                }else if (strcmp(op_name, "<>") == 0) {
                    switch (file_state->column_type_list[file_state->column_idx_list_map[i]]) {
                        case 0: {
                            std::string block_min_str = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<std::string>();
                            std::string block_max_str = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<std::string>();
                            text * constant_2_value_text =  DatumGetTextP(constant_2->constvalue);
                            int constant_2_size = VARSIZE_ANY_EXHDR(constant_2_value_text);
                            char constant_2_value_str[constant_2_size];
                            strncpy(constant_2_value_str, VARDATA_ANY(constant_2_value_text), constant_2_size);
                            constant_2_value_str[constant_2_size] = '\0';

                            if (strcasecmp(constant_2_value_str,block_max_str.c_str()) == 0 &&
                                                   strcasecmp(constant_2_value_str,block_min_str.c_str()) == 0) {
                                tuple_null = true;
                            }
                            break;
                        }
                        case 1: {
                            int block_min = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<int>();
                            int block_max = file_state->remain_tuple = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<int>();


                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (constant_2_value == block_max &&
                                        constant_2_value == block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (constant_2_value == block_max &&
                                        constant_2_value == block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (constant_2_value == block_max &&
                                        constant_2_value == block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (constant_2_value == block_max &&
                                        constant_2_value == block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                            break;
                        }
                        case 2: {
                            float block_min = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<float>();
                            float block_max = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<float>();
                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (constant_2_value == block_max &&
                                        constant_2_value == block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (constant_2_value == block_max &&
                                        constant_2_value == block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (constant_2_value == block_max &&
                                        constant_2_value == block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (constant_2_value == block_max &&
                                        constant_2_value == block_min) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }
                } else if (strcmp(op_name, ">=") == 0) {
                    switch (file_state->column_type_list[file_state->column_idx_list_map[i]]) {
                        case 0: {
                            std::string block_max_str = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<std::string>();
                            text * constant_2_value_text =  DatumGetTextP(constant_2->constvalue);
                            int constant_2_size = VARSIZE_ANY_EXHDR(constant_2_value_text);
                            char constant_2_value_str[constant_2_size];
                            strncpy(constant_2_value_str, VARDATA_ANY(constant_2_value_text), constant_2_size);
                            constant_2_value_str[constant_2_size] = '\0';


                            if (strcasecmp(block_max_str.c_str(),constant_2_value_str) < 0) {
                                tuple_null = true;
                            }
                            break;
                        }
                        case 1: {
                            int block_max = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<int>();


                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (block_max < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (block_max < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (block_max < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (block_max < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }


                            break;
                        }
                        case 2: {
                            float block_max = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["max"].get<float>();
                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (block_max < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (block_max < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (block_max < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (block_max < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }

                }  else if (strcmp(op_name, "<=") == 0) {
                    switch (file_state->column_type_list[file_state->column_idx_list_map[i]]) {
                        case 0: {
                            std::string block_min_str = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<std::string>();
                            text * constant_2_value_text =  DatumGetTextP(constant_2->constvalue);
                            int constant_2_size = VARSIZE_ANY_EXHDR(constant_2_value_text);
                            char constant_2_value_str[constant_2_size];
                            strncpy(constant_2_value_str, VARDATA_ANY(constant_2_value_text), constant_2_size);
                            constant_2_value_str[constant_2_size] = '\0';


                            if (strcasecmp(block_min_str.c_str(),constant_2_value_str) > 0) {
                                tuple_null = true;
                            }
                            break;
                        }
                        case 1: {
                            int block_min = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<int>();

                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (block_min > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (block_min > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (block_min > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (block_min > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                            break;
                        }
                        case 2: {
                            float block_min = file_state->metadata["Columns"][column_name]["block_stats"][
                                    std::to_string(file_state->block_idx)]["min"].get<float>();
                            switch (constant_2->consttype) {
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (block_min > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (block_min > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (block_min > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (block_min > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
                if (tuple_null) {
                    break;
                }
            }


//            elog(LOG, "db721_IterateForeignScan 679,tuple null %s", tuple_null ? "true" : "false");
            if (tuple_null) {
                file_state->block_idx++;
                file_state->tuple_idx = max_per_block;
                continue;
            }
            int buf_idx = 0;
            foreach(columnCell, file_state->column_list)
            {

                Var *column = (Var *) lfirst(columnCell);
                AttrNumber column_id = column->varattno;


//                auto column_name = get_attname(f_id, column_id, false);

                int type_size = file_state->column_type_list[file_state->column_idx_list_map[column_id - 1]] == 0? 32: 4;

                int start_index = file_state->column_start_idx[file_state->column_idx_list_map[column_id - 1]];
                int block_size = file_state->block_idx == file_state->num_block - 1 ? file_state->remain_tuple: max_per_block;
                fseek(file_state->f_oid, start_index + type_size * max_per_block * file_state->block_idx, SEEK_SET);
                size_t tmp_read_size = fread(&(file_state->buf[buf_idx]), type_size, block_size,
                                             file_state->f_oid);
                if (tmp_read_size == 0) {
                    elog(ERROR, "read went wrong during iterate scanning");
                }
                file_state->column_idx_list[file_state->column_idx_list_map[column_id - 1]] = buf_idx;
                buf_idx += block_size * type_size;
            }
            file_state->block_idx++;
            break;
        }

        if (tuple_null) {
            return tupleSlot;
        }


        while (((file_state->block_idx != file_state->num_block) && (file_state->tuple_idx < max_per_block)) ||
               ((file_state->block_idx == file_state->num_block) &&
                (file_state->tuple_idx < file_state->remain_tuple))) {
            file_state->tuple_idx++;
            ListCell *tmp_column_cell = NULL;
            tuple_null = false;

            ListCell *restrictInfoCell = NULL;
            char * last_string = NULL;
            int last_int = 0;
            float last_float = 0;
            int last_column_id = -1;
            foreach(restrictInfoCell, restrictInfoList)
            {
                OpExpr *ope_expr = (OpExpr *) lfirst(restrictInfoCell);

                Var * left_var;
                if (IsA(linitial(ope_expr->args), RelabelType)){
                    left_var = (Var *) (((RelabelType *) linitial(ope_expr->args))->arg);
                }else {
                    left_var = (Var *) linitial(ope_expr->args);
                }

                Const *constant_2 = (Const *) lsecond(ope_expr->args);
                char *op_name = get_opname(ope_expr->opno);
                AttrNumber column_id = left_var->varattno;
                int i = column_id - 1;

                switch(file_state->column_type_list[file_state->column_idx_list_map[i]]) {
                    case 0: {
                        char *string_value;
                        if (column_id == last_column_id){
                            string_value = last_string;
                        }else{
                            string_value= &(file_state->buf[file_state->column_idx_list[file_state->column_idx_list_map[i]]]);
                            last_string = string_value;
                        }
                        text * constant_2_value_text =  DatumGetTextP(constant_2->constvalue);
                        int constant_2_size = VARSIZE_ANY_EXHDR(constant_2_value_text);
                        char constant_2_value_str[constant_2_size];
                        strncpy(constant_2_value_str, VARDATA_ANY(constant_2_value_text), constant_2_size);
                        constant_2_value_str[constant_2_size] = '\0';
                        if (strcmp(op_name, "=") == 0) {
                            if (strcasecmp(string_value, constant_2_value_str) != 0) {
                                tuple_null = true;
                            }
                        } else if (strcmp(op_name, "<>") == 0) {
                            if (strcasecmp(string_value, constant_2_value_str) == 0) {
                                tuple_null = true;
                            }
                        } else if (strcmp(op_name, ">=") == 0) {
                            if (strcasecmp(string_value,constant_2_value_str) < 0) {
                                tuple_null = true;
                            }

                        } else if (strcmp(op_name, "<") == 0) {
                            if (strcasecmp(string_value, constant_2_value_str) >= 0) {
                                tuple_null = true;
                            }
                        } else if (strcmp(op_name, ">") == 0) {
                            if (strcasecmp(string_value, constant_2_value_str) <= 0) {
                                tuple_null = true;
                            }
                        } else if (strcmp(op_name, "<=") == 0) {
                            if (strcasecmp(string_value, constant_2_value_str) > 0) {
                                tuple_null = true;
                            }
                        }
                        break;
                    }
                    case 1:{
                        int int_value;
                        if (column_id == last_column_id){
                            int_value = last_int;
                        }else{
                            memcpy(&int_value, &file_state->buf[file_state->column_idx_list[file_state->column_idx_list_map[i]]],
                                   4);
                            last_int = int_value;
                        }
                        if (strcmp(op_name, ">") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (int_value <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (int_value <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (int_value <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (int_value <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }else if (strcmp(op_name, "<") == 0) {
//                            elog(LOG, "db721_IterateForeignScan int value: %d, const value: %d", int_value, constant_2->constvalue);
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (int_value >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (int_value >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (int_value >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (int_value >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }else if (strcmp(op_name, "=") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (int_value != constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (int_value != constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (int_value != constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (int_value != constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }  else if (strcmp(op_name, "<>") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (int_value == constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (int_value == constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (int_value == constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (int_value == constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        } else if (strcmp(op_name, ">=") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (int_value < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (int_value < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (int_value < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (int_value < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }  else if (strcmp(op_name, "<=") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (int_value > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (int_value > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (int_value > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double  constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (int_value > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }
                        break;
                    }
                    case 2:{
                        float float_value;
                        if (column_id == last_column_id){
                            float_value = last_float;
                        }else{
                            memcpy(&float_value,
                                   &file_state->buf[file_state->column_idx_list[file_state->column_idx_list_map[i]]], 4);
                            last_float = float_value;
                        }
                        if (strcmp(op_name, ">") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (float_value <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (float_value <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (float_value <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (float_value <= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }else if (strcmp(op_name, "<") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (float_value >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (float_value >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (float_value >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (float_value >= constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }
                        } else if (strcmp(op_name, "=") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (float_value != constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (float_value != constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (float_value != constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (float_value != constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }  else if (strcmp(op_name, "<>") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (float_value == constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (float_value == constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (float_value == constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (float_value == constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        } else if (strcmp(op_name, ">=") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (float_value < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (float_value < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (float_value < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (float_value < constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }  else if (strcmp(op_name, "<=") == 0) {
                            switch (constant_2->consttype){
                                case INT4OID: {
                                    int constant_2_value = DatumGetInt32(constant_2->constvalue);
                                    if (float_value > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case INT8OID: {
                                    int64 constant_2_value = DatumGetInt64(constant_2->constvalue);
                                    if (float_value > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT4OID: {
                                    float constant_2_value = DatumGetFloat4(constant_2->constvalue);
                                    if (float_value > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                                case FLOAT8OID: {
                                    double constant_2_value = DatumGetFloat8(constant_2->constvalue);
                                    if (float_value > constant_2_value) {
                                        tuple_null = true;
                                    }
                                    break;
                                }
                            }

                        }
                        break;
                    }
                }
                if (tuple_null){
                    break;
                }
                last_column_id = column_id;

            }

            if (!tuple_null) {

                foreach(tmp_column_cell, target_list)
                {

                    TargetEntry *tmp_target = (TargetEntry *) lfirst(tmp_column_cell);

                    if (tmp_target->resjunk) {
                        continue;
                    }
                    Var *tmp_column = (Var *) tmp_target->expr;

                    int i = tmp_column->varattno - 1;
                    if (!columnNulls[i]){
                        continue;
                    }

                    switch (file_state->column_type_list[file_state->column_idx_list_map[i]]) {
                        case 0: {
                            columnValues[i] = CStringGetTextDatum(
                                    &(file_state->buf[file_state->column_idx_list[file_state->column_idx_list_map[i]]]));
                            columnNulls[i] = false;

                            break;
                        }
                        case 1: {
                            int int_value;

                            memcpy(&int_value, &file_state->buf[file_state->column_idx_list[file_state->column_idx_list_map[i]]],
                                   4);

                            columnValues[i] = Int32GetDatum(int_value);
                            columnNulls[i] = false;
                            break;
                        }
                        case 2: {
                            float float_value;
                            memcpy(&float_value,
                                   &file_state->buf[file_state->column_idx_list[file_state->column_idx_list_map[i]]], 4);

                            columnValues[i] = Float4GetDatum(float_value);
                            columnNulls[i] = false;
                            break;
                        }
                    }

                }
            }

            for (int i = 0; i < num_columns; i++) {
                switch (file_state->column_type_list[i]) {
                    case 0:
                        file_state->column_idx_list[i] += 32;
                        break;
                    case 1:
                    case 2:
                        file_state->column_idx_list[i] += 4;
                        break;
                }
            }

            if (!tuple_null) {
                ExecStoreVirtualTuple(tupleSlot);
                return tupleSlot;
            }
        }

    }

    return tupleSlot;

}

extern "C" void db721_ReScanForeignScan(ForeignScanState *node) {
    Db721_file * file_state = (Db721_file *) node->fdw_state;
    file_state->block_idx = 0;
    file_state->tuple_idx = file_state->max_per_block;
}

extern "C" void db721_EndForeignScan(ForeignScanState *node) {
    Db721_file * file_state = (Db721_file *)node->fdw_state;
    fclose(file_state->f_oid);
    pfree(file_state->buf);
    pfree(file_state->column_idx_list);
    pfree(file_state->column_type_list);
    pfree(file_state->column_idx_list_map);
    pfree(file_state->column_start_idx);
    pfree(file_state);


}